import React from 'react';

const Footer = () => {
  return (
    <div className="footer">
      <p>© 2025 Posters Dukaan. Made with 💖</p>
    </div>
  );
};

export default Footer;